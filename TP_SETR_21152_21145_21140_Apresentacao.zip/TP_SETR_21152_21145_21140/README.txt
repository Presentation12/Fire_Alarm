Devido a sensibilidade do sensor de inclinação não foi possivel o uso do butão e então foi
inserido um print no serial monitor que o comprova. Tambem foi enviado junto a montagem e funcionamento
no tinkercad para comprovar o seu funcionamento.
No relatório encontra-se tambem o link(tinkercad) e arquitura de ambas.

BREVE DESCRIÇÃO
--------------------------
Alarme de fogo
No alarme de fogo é realizado uma passagem breve de luz para frente e para trás de forma a imitar
o fogo e no qual o alarme mantem se ativo nessa situação

Alarme de inclinação 
Ativo quando ocorre uma inclinação simulando uma derrucada, e é desativado através do botão